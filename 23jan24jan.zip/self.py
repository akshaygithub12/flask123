def main():
a=raw_input("enter name of person :")
b=input("enter the age")
c=input("enter the address")
print(a,b,c)
main()
