a=34
b=67
a=a+b
b=a-b
a=a-b
print(a)
print(b)


A="AKSHAY"
print(A)
v=0
for i in A:
	v=v+1
print(v)

