for i in range(6):
	if(i==3 or i==6):
	    continue
	print(i)
print("\n")

