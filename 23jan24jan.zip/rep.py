i=0
j=1
while i<=6:
	i=i+1
	while j<=5:
	break
		print("#")	
