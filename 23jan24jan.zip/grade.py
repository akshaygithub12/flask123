a=input("enter the first marks")
b=input("enter the first marks")
c=input("enter the first marks")
d=input("enter the first marks")
e=input("enter the first marks")
f=input("enter the first marks")

avg=(a+b+c+d+e+f)/6
print(avg)

if(avg>=70):
	print("first class")
elif(avg<=50):
	print("second class")
else:
	print("pass class")

