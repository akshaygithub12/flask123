a=raw_input("enter the name")
print(a)
for a in a:
	print(a)
