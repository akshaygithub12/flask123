i=0
while(i==6):
      i=i+1
      print(i)

