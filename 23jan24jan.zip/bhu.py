def ran(x):
x=input("enter the no")
	if x in range(1,10):
		print x ,"is in the range"
	else:
		print "invalid value", x
ran(x)
