def printList():
	num_list=range(3)
	print num_list
printList()

def asd(x,y):
	print(x*y)
asd(2,5)

def aksh():
	num=range(3)
	return num
askd=aksh()
print(askd)



name=raw_input("enter name of person :")
age=input("enter the age")
address=input("enter the address")
