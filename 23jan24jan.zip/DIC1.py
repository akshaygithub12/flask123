
a=input("enetr the a")
b=input("enter the b")
phone={"john":987656567,
"jack":98675672561,
"jill":9864326262,
a:b
}
print(phone)
phone["john"]=938273443
print(phone)

del phone['jill']
print(phone)

if "jack" in phone:
	print("yes exist")



