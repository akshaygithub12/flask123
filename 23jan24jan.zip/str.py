daa="aksajhsah.exe"
print(daa)
print(daa[2])
print(daa[-1])
print(len(daa))
print(daa[0:8])
