month={"dr":"dadar","b":"badra","pr":"parel"}
print(month)
for key in month:
	print(key)
for value in month:
	print(value)

if(month["dr"]=="dadar"):
	print "the next station is", month[key]
else:
	print "doent exist"

